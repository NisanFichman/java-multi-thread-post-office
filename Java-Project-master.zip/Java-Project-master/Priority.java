
public enum Priority {
	LOW, STANDARD, HIGH

}
