import java.util.Random;

public class tetser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		Truck t1=new Truck();
		System.out.println(t1.getTruckModel());
		System.out.println(t1.getLicensePlate());
		System.out.println(t1.getTruckID());
		System.out.println(t1.getAvailable());
		Truck t2=new Truck();
		System.out.println(t1.getTruckModel());
		System.out.println(t1.getLicensePlate());
		System.out.println(t1.getTruckID());
		System.out.println(t1.getAvailable());
		*/
		Random rand = new Random();
		double choice=rand.nextDouble();
		System.out.println(choice);

		/*
		System.out.println(t3.getTruckModel());
		System.out.println(t3.getLicensePlate());
		System.out.println(t3.getTruckID());
		System.out.println(t3.getAvailable());
		*/


	}

}
