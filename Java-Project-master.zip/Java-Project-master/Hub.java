
public class Hub extends Branch implements Node{
	Branch[] branches;
	public Hub(){
		
	}
	
	 
	 

	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deliverPackage(Package p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void collectPackage(Package p) {
		// TODO Auto-generated method stub
		
	}
	

}
