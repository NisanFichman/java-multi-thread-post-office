
public interface Node {
	public void work();
	void deliverPackage(Package p);
	void collectPackage(Package p);
	

}
